//
//  AddTableViewCell.swift
//  DataBaseDemoProject
//
//  Created by Sagar Somaiya on 13/03/19.
//  Copyright © 2019 Sagar Somaiya. All rights reserved.
//

import UIKit

class AddTableViewCell: UITableViewCell {
    
    @IBOutlet weak var labelPlace: UILabel!
    @IBOutlet weak var labelName: UILabel!
   
    static let identifier = String(describing: AddTableViewCell.self)
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
