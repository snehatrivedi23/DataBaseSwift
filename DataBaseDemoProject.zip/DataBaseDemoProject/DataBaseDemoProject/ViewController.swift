//
//  ViewController.swift
//  DataBaseDemoProject
//
//  Created by Sagar Somaiya on 13/03/19.
//  Copyright © 2019 Sagar Somaiya. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet var TableData: UITableView!
    var database:NSMutableArray = NSMutableArray()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.TableData.register(AddTableViewCell.self, forCellReuseIdentifier: "cell")
        self.TableData.rowHeight = UITableView.automaticDimension
        self.TableData.estimatedRowHeight = 100
        self.TableData.tableFooterView = UIView(frame: CGRect.zero)
        let select:String = "SELECT * FROM STUDENT"
        database = Database.share().selectAll(fromTable: select)
        print(database)
        TableData.delegate = self
        TableData.dataSource = self
        TableData.reloadData()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        let select:String = "SELECT * FROM STUDENT"
        database = Database.share().selectAll(fromTable: select)
        print(database)
        
        TableData.reloadData()
    }
    @IBAction func BtnAdd(_ sender: UIButton)
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier:"AddViewController") as! AddViewController
        
        nextViewController.status = -1
        //self.present(nextViewController, animated:true, completion:nil)
        self.navigationController?.pushViewController(nextViewController, animated: true)
        
        
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return database.count
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = TableData.dequeueReusableCell(withIdentifier: "cell", for:indexPath) as! AddTableViewCell
        //cell.LblName.text = arraydata.object(at: indexPath.row) as? String
        print((database.object(at: indexPath.row) as AnyObject).value(forKey: "Name") as? String as Any)
      
        return cell
    }
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        //check = true
        let nextViewController = storyBoard.instantiateViewController(withIdentifier:"AddViewController") as! AddViewController
        
        nextViewController.name = ((database.object(at: indexPath.row) as AnyObject).value(forKey: "Name") as? String)!
        
        nextViewController.place = ((database.object(at: indexPath.row) as AnyObject).value(forKey: "Semester") as? String)!
        
        nextViewController.status = indexPath.row
        
        //self.present(nextViewController, animated:true, completion:nil)
      self.navigationController?.pushViewController(nextViewController, animated: true)
        
    }
    //    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
    //
    //        let editAction = UITableViewRowAction(style: .normal, title: "Edit")
    //        {
    //            (rowAction, indexPath) in
    //            //TODO: edit the row at indexPath here
    //        }
    //        editAction.backgroundColor = .blue
    //
    //        let deleteAction = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
    //            //TODO: Delete the row at indexPath here
    //        }
    //        deleteAction.backgroundColor = .red
    //
    //        return [editAction,deleteAction]
    //    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete
        {
            database.removeObject(at: indexPath.row)
            self.TableData.reloadData()
        }
    }
    

}
@IBDesignable extension UIButton {
    
    @IBInspectable var borderWidth: CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
        }
        get {
            return layer.cornerRadius
        }
    }
    
    @IBInspectable var borderColor: UIColor? {
        set {
            guard let uiColor = newValue else { return }
            layer.borderColor = uiColor.cgColor
        }
        get {
            guard let color = layer.borderColor else { return nil }
            return UIColor(cgColor: color)
        }
    }
}
